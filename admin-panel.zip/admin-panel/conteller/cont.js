const usermodel=require('../model/usermodel');
const dashboard =(req,res)=>{
    res.render('index');
}
const getform =(req,res)=>{
    res.render('form');
}
const getpostData = async(req,res)=>{
    const checkuser =await usermodel.findOne({email:req.body.email});
    if(checkuser){
        return res.send("emial ready");

    }else{
        const result = new usermodel({
            id:1,
            name:req.body.name,
            email:req.body.email,
            password:req.body.password,
        
        })
        const res1 = await result.save()
        console.log("data inserted successfully"+res1)
        res.send("data inserted successfully")
    }
    const result = new usermodel({
        id:1,
        name:req.body.name,
        email:req.body.email,
        password:req.body.password,
    
    })
    const res1 = await result.save()
    console.log("data converted"+res1)
    res.send("data converted")

}
const checkusertdata =async(req, res)=>{
    const checkuser =await usermodel.findOne({
        email:req.body.email,
        password:req.body.password
    });
      if(checkuser){
        res.redirect("/admin")
      }
    
}
module.exports={
    dashboard,
    getform,
    getpostData,
    checkusertdata
}         