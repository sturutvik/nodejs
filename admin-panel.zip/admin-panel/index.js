const  express = require('express')
const app = express()
app.use(express.static(__dirname))
const routes = require("./routes/user")
app.set ('view engine', 'ejs')
app.use(routes)

//   ****** //
app.get ('/',(req,res)=>{
     res.end("admin panel")
})
app.get ('/login',(req,res)=>{
    res.render('login')
})
app.get ('/register',(req,res)=>{
    res.render('register')
})
app.listen('1111',()=>{
    console.log("listening on 1111");
});