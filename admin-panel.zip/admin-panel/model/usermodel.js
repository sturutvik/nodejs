
const mongoose = require('mongoose')
const mdata = async()=>{
    const url ="mongodb://127.0.0.1:27017/student"
    await mongoose.connect(url)

}
mdata()
const studentschema = new mongoose.Schema({
    id :Number,
    name:{
         type:String,
         required:true,
         unique:true,
    },
    email:{
        type:String,
        required:true,
        unique:true,
   },
    
    password:String
})
const studentsmodel = new mongoose.model('database',studentschema)
module.exports=studentsmodel