const express = require('express');
const router = express.Router();
const body = require('body-parser');
const bodyparser = body.urlencoded({extended:false});
const {dashboard,getform,getpostData,checkusertdata}=require("../conteller/cont");

router.get('/admin' ,dashboard);
router.get('/admin/form' ,getform);
router.post('/admin/savedata',bodyparser,getpostData);
router.post('/login',bodyparser,checkusertdata);
module.exports = router;